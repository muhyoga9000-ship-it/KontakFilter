package id.rayz.kontakfilter;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.ContentProviderOperation;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.InputType;
import android.view.View;
import android.view.Gravity;
import android.view.ViewGroup;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.widget.HorizontalScrollView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends Activity {
    private static final int REQUEST_READ_CONTACTS = 1001;
    private static final int REQUEST_CONTACT_PERMISSIONS = 1002;
    private static final int MAX_GENERATED_CONTACTS = 1000;

    private EditText searchInput;
    private TextView countText;
    private TextView statusText;
    private ListView contactsList;
    private final Map<Long, ContactItem> contacts = new LinkedHashMap<>();
    private final List<String> visibleRows = new ArrayList<>();
    private ArrayAdapter<String> adapter;
    private String activeFilter = "Semua";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildInterface();
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS)
                == PackageManager.PERMISSION_GRANTED) {
            loadContacts();
        } else {
            requestPermissions(new String[]{Manifest.permission.READ_CONTACTS},
                    REQUEST_READ_CONTACTS);
        }
    }

    private void buildInterface() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(12), dp(18), dp(6));
        root.setBackgroundColor(0xFFF4F7FB);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setOrientation(LinearLayout.HORIZONTAL);
        TextView mark = new TextView(this);
        mark.setText("K"); mark.setTextSize(24); mark.setTextColor(Color.WHITE);
        mark.setGravity(Gravity.CENTER); mark.setTypeface(null, Typeface.BOLD);
        mark.setBackground(round(0xFF2563EB, 16));
        top.addView(mark, new LinearLayout.LayoutParams(dp(48), dp(48)));
        LinearLayout titleBox = new LinearLayout(this); titleBox.setOrientation(LinearLayout.VERTICAL);
        titleBox.setPadding(dp(12), 0, 0, 0);
        TextView title = new TextView(this); title.setText("KontakFilter"); title.setTextSize(23);
        title.setTextColor(0xFF14213D); title.setTypeface(null, Typeface.BOLD);
        titleBox.addView(title, matchWrap());
        TextView subtitle = new TextView(this); subtitle.setText("Kelola nomor dengan lebih cerdas");
        subtitle.setTextSize(12); subtitle.setTextColor(0xFF718096);
        titleBox.addView(subtitle, matchWrap());
        top.addView(titleBox, new LinearLayout.LayoutParams(0, -2, 1));
        TextView local = new TextView(this); local.setText("● LOKAL"); local.setTextSize(10);
        local.setTextColor(0xFF087F5B); local.setPadding(dp(9), dp(7), dp(9), dp(7));
        local.setBackground(round(0xFFDDF7EC, 20)); top.addView(local);
        LinearLayout.LayoutParams topP = matchWrap(); topP.bottomMargin = dp(16); root.addView(top, topP);

        LinearLayout hero = new LinearLayout(this); hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(dp(16), dp(16), dp(16), dp(16));
        hero.setBackground(round(0xFF172B4D, 20));
        TextView heroTitle = new TextView(this); heroTitle.setText("Temukan nomor yang kamu cari");
        heroTitle.setTextSize(18); heroTitle.setTextColor(Color.WHITE); heroTitle.setTypeface(null, Typeface.BOLD);
        hero.addView(heroTitle, matchWrap());
        TextView heroSub = new TextView(this); heroSub.setText("Cari kontak lalu saring berdasarkan integrasi yang terdeteksi di perangkat.");
        heroSub.setTextSize(12); heroSub.setTextColor(0xFFD4DFEF);
        LinearLayout.LayoutParams hsp = matchWrap(); hsp.topMargin = dp(5); hsp.bottomMargin = dp(13); hero.addView(heroSub, hsp);

        searchInput = new EditText(this); searchInput.setSingleLine(true);
        searchInput.setHint("  Cari nama atau nomor..."); searchInput.setTextSize(14);
        searchInput.setTextColor(0xFF182230); searchInput.setHintTextColor(0xFF8793A5);
        searchInput.setPadding(dp(12), dp(2), dp(12), dp(2)); searchInput.setBackground(round(Color.WHITE, 12));
        if (android.os.Build.VERSION.SDK_INT >= 21) searchInput.setElevation(dp(1));
        hero.addView(searchInput, new LinearLayout.LayoutParams(-1, dp(48)));
        LinearLayout.LayoutParams hp = matchWrap(); hp.bottomMargin = dp(10); root.addView(hero, hp);

        TextView addContactsButton = new TextView(this);
        addContactsButton.setText("＋  Tambah Kontak Berurutan");
        addContactsButton.setTextSize(14);
        addContactsButton.setTypeface(null, Typeface.BOLD);
        addContactsButton.setTextColor(Color.WHITE);
        addContactsButton.setGravity(Gravity.CENTER);
        addContactsButton.setPadding(dp(12), dp(14), dp(12), dp(14));
        addContactsButton.setBackground(round(0xFF0F9D78, 13));
        LinearLayout.LayoutParams addButtonParams = matchWrap();
        addButtonParams.bottomMargin = dp(12);
        root.addView(addContactsButton, addButtonParams);
        addContactsButton.setOnClickListener(v -> {
            if (checkSelfPermission(Manifest.permission.WRITE_CONTACTS) == PackageManager.PERMISSION_GRANTED) {
                showAddContactsDialog();
            } else {
                requestPermissions(new String[]{Manifest.permission.WRITE_CONTACTS}, REQUEST_CONTACT_PERMISSIONS);
            }
        });

        TextView section = new TextView(this); section.setText("FILTER NOMOR"); section.setTextSize(11);
        section.setTextColor(0xFF667085); section.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams secP = matchWrap(); secP.bottomMargin = dp(5); root.addView(section, secP);
        HorizontalScrollView hsv = new HorizontalScrollView(this); hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout filters = new LinearLayout(this); filters.setOrientation(LinearLayout.HORIZONTAL);
        String[] labels = {"Semua", "WhatsApp", "Telegram", "Keduanya"};
        for (String label : labels) {
            TextView chip = new TextView(this); chip.setText(label); chip.setTextSize(12);
            chip.setGravity(Gravity.CENTER); chip.setTypeface(null, Typeface.BOLD);
            chip.setPadding(dp(15), dp(10), dp(15), dp(10));
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-2, -2); cp.rightMargin = dp(8);
            filters.addView(chip, cp);
            chip.setOnClickListener(v -> { activeFilter = label; updateFilterLabels(filters, labels); applyFilter(searchInput.getText().toString()); });
        }
        hsv.addView(filters); root.addView(hsv, matchWrap()); updateFilterLabels(filters, labels);

        LinearLayout summary = new LinearLayout(this); summary.setOrientation(LinearLayout.VERTICAL);
        summary.setPadding(dp(13), dp(11), dp(13), dp(11)); summary.setBackground(round(Color.WHITE, 14));
        countText = new TextView(this); countText.setTextSize(13); countText.setTextColor(0xFF24324B); countText.setTypeface(null, Typeface.BOLD);
        summary.addView(countText, matchWrap());
        statusText = new TextView(this); statusText.setTextSize(11); statusText.setTextColor(0xFF718096);
        LinearLayout.LayoutParams stp = matchWrap(); stp.topMargin = dp(4); summary.addView(statusText, stp);
        LinearLayout.LayoutParams sumP = matchWrap(); sumP.topMargin = dp(12); sumP.bottomMargin = dp(8); root.addView(summary, sumP);

        contactsList = new ListView(this); contactsList.setDivider(null); contactsList.setSelector(android.R.color.transparent);
        contactsList.setCacheColorHint(Color.TRANSPARENT);
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, visibleRows) {
            @Override public View getView(int position, View convertView, ViewGroup parent) {
                String raw = getItem(position); String[] lines = raw == null ? new String[0] : raw.split("\n");
                LinearLayout card = new LinearLayout(MainActivity.this); card.setOrientation(LinearLayout.VERTICAL);
                card.setPadding(dp(14), dp(13), dp(14), dp(13)); card.setBackground(round(Color.WHITE, 16));
                if (android.os.Build.VERSION.SDK_INT >= 21) card.setElevation(dp(1));
                LinearLayout.LayoutParams cardP = new LinearLayout.LayoutParams(-1, -2); cardP.bottomMargin = dp(9);
                card.setLayoutParams(cardP);
                String first = lines.length > 0 ? lines[0] : "Kontak";
                int split = first.lastIndexOf("  ·  ID "); String contactName = split >= 0 ? first.substring(0, split) : first;
                String contactId = split >= 0 ? first.substring(split + 8) : "—";
                LinearLayout header = new LinearLayout(MainActivity.this); header.setOrientation(LinearLayout.HORIZONTAL); header.setGravity(Gravity.CENTER_VERTICAL);
                TextView avatar = new TextView(MainActivity.this); avatar.setText(contactName.trim().isEmpty() ? "?" : contactName.trim().substring(0,1).toUpperCase(Locale.ROOT));
                avatar.setTextColor(0xFF2457C5); avatar.setTextSize(15); avatar.setTypeface(null, Typeface.BOLD); avatar.setGravity(Gravity.CENTER); avatar.setBackground(round(0xFFE8F0FF, 13));
                header.addView(avatar, new LinearLayout.LayoutParams(dp(40), dp(40)));
                LinearLayout nameBox = new LinearLayout(MainActivity.this); nameBox.setOrientation(LinearLayout.VERTICAL); nameBox.setPadding(dp(10),0,0,0);
                TextView name = new TextView(MainActivity.this); name.setText(contactName); name.setTextSize(15); name.setTextColor(0xFF1D2939); name.setTypeface(null, Typeface.BOLD); nameBox.addView(name, matchWrap());
                TextView id = new TextView(MainActivity.this); id.setText("ID kontak · " + contactId); id.setTextSize(10); id.setTextColor(0xFF98A2B3); nameBox.addView(id, matchWrap());
                header.addView(nameBox, new LinearLayout.LayoutParams(0,-2,1));
                TextView total = new TextView(MainActivity.this); total.setText(Math.max(0, lines.length-1) + " nomor"); total.setTextSize(10); total.setTextColor(0xFF475467); total.setPadding(dp(8),dp(5),dp(8),dp(5)); total.setBackground(round(0xFFF2F4F7,20)); header.addView(total);
                card.addView(header);
                for (int i=1;i<lines.length;i++) {
                    String line = lines[i].trim(); if (line.startsWith("• ")) line = line.substring(2);
                    int sep = line.indexOf(" — "); String number = sep >= 0 ? line.substring(0,sep) : line;
                    String services = sep >= 0 ? line.substring(sep+3) : "Integrasi tidak terdeteksi";
                    LinearLayout nr = new LinearLayout(MainActivity.this); nr.setOrientation(LinearLayout.VERTICAL); nr.setPadding(dp(10),dp(9),dp(10),dp(9)); nr.setBackground(round(0xFFF7F9FC,10));
                    LinearLayout.LayoutParams nrp = matchWrap(); nrp.topMargin = dp(9); card.addView(nr,nrp);
                    TextView num = new TextView(MainActivity.this); num.setText(number); num.setTextSize(14); num.setTextColor(0xFF344054); num.setTypeface(Typeface.MONOSPACE,Typeface.BOLD); nr.addView(num,matchWrap());
                    TextView badge = new TextView(MainActivity.this); badge.setText(services); badge.setTextSize(10); badge.setPadding(dp(7),dp(4),dp(7),dp(4));
                    if (services.contains("WhatsApp") || services.contains("Telegram")) { badge.setTextColor(0xFF087F5B); badge.setBackground(round(0xFFDDF7EC,8)); }
                    else { badge.setTextColor(0xFF667085); badge.setBackground(round(0xFFEAECF0,8)); }
                    LinearLayout.LayoutParams bp = matchWrap(); bp.topMargin = dp(5); nr.addView(badge,bp);
                }
                return card;
            }
        };
        contactsList.setAdapter(adapter);
        LinearLayout.LayoutParams listP = new LinearLayout.LayoutParams(-1, 0, 1f); listP.topMargin = dp(2); root.addView(contactsList,listP);
        setContentView(root);
        searchInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { applyFilter(s == null ? "" : s.toString()); }
            @Override public void afterTextChanged(Editable s) {}
        });
    }

    private GradientDrawable round(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }

    private void updateFilterLabels(LinearLayout filters, String[] labels) {
        for (int i=0; i<filters.getChildCount(); i++) {
            TextView chip = (TextView) filters.getChildAt(i);
            boolean selected = labels[i].equals(activeFilter);
            chip.setTextColor(selected ? Color.WHITE : 0xFF475467);
            chip.setBackground(round(selected ? 0xFF2563EB : Color.WHITE, 22));
        }
    }

    private void showAddContactsDialog() {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(22), dp(8), dp(22), 0);

        EditText startNumber = new EditText(this);
        startNumber.setSingleLine(true);
        startNumber.setInputType(InputType.TYPE_CLASS_PHONE);
        startNumber.setHint("Nomor awal, contoh +6281234567800");
        form.addView(startNumber, matchWrap());

        EditText quantityInput = new EditText(this);
        quantityInput.setSingleLine(true);
        quantityInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        quantityInput.setHint("Jumlah kontak (maks. " + MAX_GENERATED_CONTACTS + ")");
        form.addView(quantityInput, matchWrap());

        EditText baseNameInput = new EditText(this);
        baseNameInput.setSingleLine(true);
        baseNameInput.setText("malikwa");
        baseNameInput.setHint("Nama dasar kontak");
        form.addView(baseNameInput, matchWrap());

        TextView note = new TextView(this);
        note.setText("Kontak disimpan langsung ke buku kontak perangkat. Nomor berurutan belum tentu aktif atau terdaftar di aplikasi pesan.");
        note.setTextSize(12);
        note.setTextColor(0xFF667085);
        LinearLayout.LayoutParams noteParams = matchWrap();
        noteParams.topMargin = dp(8);
        form.addView(note, noteParams);

        new AlertDialog.Builder(this)
                .setTitle("Tambah kontak berurutan")
                .setView(form)
                .setNegativeButton("Batal", null)
                .setPositiveButton("Tambah", (dialog, which) -> {
                    String rawStart = startNumber.getText().toString().trim();
                    String rawQuantity = quantityInput.getText().toString().trim();
                    String baseName = baseNameInput.getText().toString().trim();
                    String cleaned = rawStart.replaceAll("[\\s().-]", "");
                    if (!cleaned.matches("\\+[0-9]+")) {
                        Toast.makeText(this, "Nomor awal harus format internasional, misalnya +6281234567800.", Toast.LENGTH_LONG).show();
                        return;
                    }
                    int quantity;
                    try { quantity = Integer.parseInt(rawQuantity); }
                    catch (Exception e) { quantity = 0; }
                    if (quantity < 1 || quantity > MAX_GENERATED_CONTACTS) {
                        Toast.makeText(this, "Jumlah harus 1 sampai " + MAX_GENERATED_CONTACTS + ".", Toast.LENGTH_LONG).show();
                        return;
                    }
                    if (baseName.isEmpty()) baseName = "Kontak";
                    addSequentialContacts(cleaned, quantity, baseName);
                })
                .show();
    }

    private void addSequentialContacts(String startNumber, int quantity, String baseName) {
        String digits = startNumber.substring(1);
        int digitLength = digits.length();
        long start;
        try { start = Long.parseLong(digits); }
        catch (NumberFormatException e) {
            Toast.makeText(this, "Nomor terlalu panjang untuk diproses.", Toast.LENGTH_LONG).show();
            return;
        }
        long end = start + quantity - 1L;
        if (end < start || Long.toString(end).length() > digitLength) {
            Toast.makeText(this, "Jumlah terlalu besar untuk panjang digit nomor awal.", Toast.LENGTH_LONG).show();
            return;
        }
        if (checkSelfPermission(Manifest.permission.WRITE_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Izin menulis kontak belum diberikan.", Toast.LENGTH_LONG).show();
            return;
        }

        int added = 0;
        int skipped = 0;
        int failed = 0;
        ContentResolver resolver = getContentResolver();
        for (int i = 0; i < quantity; i++) {
            String phone = "+" + String.format(Locale.ROOT, "%0" + digitLength + "d", start + i);
            if (phoneAlreadyExists(phone)) { skipped++; continue; }
            String name = baseName + (i + 1);
            try {
                ArrayList<ContentProviderOperation> ops = new ArrayList<>();
                ops.add(ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI)
                        .withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null)
                        .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null)
                        .build());
                ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                        .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                        .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE)
                        .withValue(ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME, name)
                        .withValue(ContactsContract.CommonDataKinds.StructuredName.GIVEN_NAME, name)
                        .build());
                ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                        .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                        .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE)
                        .withValue(ContactsContract.CommonDataKinds.Phone.NUMBER, phone)
                        .withValue(ContactsContract.CommonDataKinds.Phone.TYPE, ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE)
                        .build());
                resolver.applyBatch(ContactsContract.AUTHORITY, ops);
                added++;
            } catch (Exception e) {
                failed++;
            }
        }
        loadContacts();
        new AlertDialog.Builder(this)
                .setTitle("Proses selesai")
                .setMessage("Berhasil ditambahkan: " + added + "\nSudah ada, dilewati: " + skipped + "\nGagal: " + failed)
                .setPositiveButton("OK", null)
                .show();
    }

    private boolean phoneAlreadyExists(String phone) {
        String target = normalizeNumber(phone);
        String[] projection = {ContactsContract.CommonDataKinds.Phone.NUMBER};
        try (Cursor cursor = getContentResolver().query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                projection, null, null, null)) {
            if (cursor != null) {
                int numberColumn = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER);
                while (cursor.moveToNext()) {
                    if (target.equals(normalizeNumber(cursor.getString(numberColumn)))) return true;
                }
            }
        } catch (Exception ignored) { }
        return false;
    }

    private void loadContacts() {
        contacts.clear();
        ContentResolver resolver = getContentResolver();

        String[] phoneProjection = {
                ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
        };

        try (Cursor cursor = resolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                phoneProjection, null, null,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " COLLATE NOCASE ASC")) {
            if (cursor != null) {
                int idCol = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.CONTACT_ID);
                int nameCol = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME);
                int numberCol = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER);
                while (cursor.moveToNext()) {
                    long id = cursor.getLong(idCol);
                    String name = cursor.getString(nameCol);
                    String number = cursor.getString(numberCol);
                    if (number == null || number.trim().isEmpty()) continue;
                    ContactItem item = contacts.get(id);
                    if (item == null) {
                        item = new ContactItem(id,
                                name == null || name.trim().isEmpty() ? "(Tanpa nama)" : name.trim());
                        contacts.put(id, item);
                    }
                    String cleanNumber = number.trim();
                    boolean exists = false;
                    for (NumberItem n : item.numbers) {
                        if (normalizeNumber(n.number).equals(normalizeNumber(cleanNumber))) {
                            exists = true;
                            break;
                        }
                    }
                    if (!exists) item.numbers.add(new NumberItem(id, cleanNumber));
                }
            }
        } catch (Exception e) {
            statusText.setText("Gagal membaca nomor: " + e.getClass().getSimpleName());
            return;
        }

        // Strict per-number matching: an app-linked row is assigned only if one of its
        // exposed data fields matches a phone number on the same Android contact ID.
        // Never copy a contact-level flag to every number in a merged contact.
        String[] dataProjection = {
                ContactsContract.Data.CONTACT_ID,
                ContactsContract.Data.MIMETYPE,
                ContactsContract.Data.DATA1,
                ContactsContract.Data.DATA2,
                ContactsContract.Data.DATA3,
                ContactsContract.Data.DATA4,
                ContactsContract.Data.DATA5,
                ContactsContract.Data.DATA6,
                ContactsContract.Data.DATA7,
                ContactsContract.Data.DATA8,
                ContactsContract.Data.DATA9,
                ContactsContract.Data.DATA10,
                ContactsContract.Data.DATA11,
                ContactsContract.Data.DATA12,
                ContactsContract.Data.DATA13,
                ContactsContract.Data.DATA14,
                ContactsContract.Data.DATA15
        };
        try (Cursor cursor = resolver.query(ContactsContract.Data.CONTENT_URI,
                dataProjection, null, null, null)) {
            if (cursor != null) {
                int idCol = cursor.getColumnIndexOrThrow(ContactsContract.Data.CONTACT_ID);
                int mimeCol = cursor.getColumnIndexOrThrow(ContactsContract.Data.MIMETYPE);
                while (cursor.moveToNext()) {
                    long id = cursor.getLong(idCol);
                    String mime = cursor.getString(mimeCol);
                    if (mime == null) continue;
                    String lower = mime.toLowerCase(Locale.ROOT);
                    boolean isWa = lower.contains("whatsapp");
                    boolean isTg = lower.contains("telegram");
                    if (!isWa && !isTg) continue;
                    ContactItem item = contacts.get(id);
                    if (item == null) continue;

                    List<String> values = new ArrayList<>();
                    for (int col = 2; col < cursor.getColumnCount(); col++) {
                        String value = cursor.getString(col);
                        if (value != null && !value.trim().isEmpty()) values.add(value.trim());
                    }
                    for (NumberItem number : item.numbers) {
                        if (rowMatchesNumber(values, number.number)) {
                            if (isWa) number.whatsappLinked = true;
                            if (isTg) number.telegramLinked = true;
                        }
                    }
                }
            }
            statusText.setText("Pemeriksaan lokal selesai. Status tiap nomor hanya ditandai jika data integrasi cocok dengan nomor tersebut.");
        } catch (Exception e) {
            statusText.setText("Nomor terbaca, tetapi data integrasi tidak dapat dibaca: "
                    + e.getClass().getSimpleName());
        }
        applyFilter(searchInput.getText().toString());
    }

    private boolean rowMatchesNumber(List<String> values, String phoneNumber) {
        String target = normalizeNumber(phoneNumber);
        if (target.length() < 7) return false;
        for (String value : values) {
            String digits = normalizeNumber(value);
            if (digits.length() < 7) continue;
            if (digits.equals(target)) return true;
            // Accept country-prefix variations only when the shorter value has at least
            // 9 digits and is an exact suffix of the longer value.
            if (Math.min(digits.length(), target.length()) >= 9
                    && (digits.endsWith(target) || target.endsWith(digits))) return true;
        }
        return false;
    }

    private String normalizeNumber(String value) {
        return value == null ? "" : value.replaceAll("[^0-9]", "");
    }

    private void applyFilter(String query) {
        String q = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        visibleRows.clear();
        int waCount = 0, tgCount = 0, bothCount = 0;
        int visibleContactCount = 0;

        for (ContactItem c : contacts.values()) {
            List<NumberItem> matchedNumbers = new ArrayList<>();
            for (NumberItem n : c.numbers) {
                if (n.whatsappLinked) waCount++;
                if (n.telegramLinked) tgCount++;
                if (n.whatsappLinked && n.telegramLinked) bothCount++;

                boolean serviceMatch;
                switch (activeFilter) {
                    case "WhatsApp": serviceMatch = n.whatsappLinked; break;
                    case "Telegram": serviceMatch = n.telegramLinked; break;
                    case "Keduanya": serviceMatch = n.whatsappLinked && n.telegramLinked; break;
                    default: serviceMatch = true;
                }
                boolean queryMatch = q.isEmpty()
                        || c.name.toLowerCase(Locale.ROOT).contains(q)
                        || n.number.toLowerCase(Locale.ROOT).contains(q)
                        || normalizeNumber(n.number).contains(normalizeNumber(q));
                if (serviceMatch && queryMatch) matchedNumbers.add(n);
            }
            if (matchedNumbers.isEmpty()) continue;
            visibleContactCount++;
            StringBuilder row = new StringBuilder(c.name).append("  ·  ID ").append(c.id);
            for (NumberItem n : matchedNumbers) {
                String services = (n.whatsappLinked ? "WhatsApp" : "")
                        + (n.whatsappLinked && n.telegramLinked ? " • " : "")
                        + (n.telegramLinked ? "Telegram" : "");
                if (services.isEmpty()) services = "Integrasi tidak terdeteksi";
                row.append("\n• ").append(n.number).append(" — ").append(services);
            }
            visibleRows.add(row.toString());
        }

        adapter.notifyDataSetChanged();
        countText.setText("Kontak: " + visibleContactCount + " ditampilkan / " + contacts.size()
                + " total • Nomor WhatsApp: " + waCount + " • Telegram: " + tgCount
                + " • Keduanya: " + bothCount);
        if (visibleRows.isEmpty()) {
            statusText.setText("Tidak ada nomor yang cocok dengan filter ini.");
        } else {
            statusText.setText("Hanya nomor yang cocok dengan filter ditampilkan. 'Tidak terdeteksi' bukan bukti nomor tidak terdaftar.");
        }
    }

    private String joinNumbers(List<String> numbers) {
        StringBuilder b = new StringBuilder();
        for (String n : numbers) {
            if (b.length() > 0) b.append(" / ");
            b.append(n);
        }
        return b.toString();
    }

    private String digitsOnly(String value) {
        return value == null ? "" : value.replaceAll("[^0-9]", "");
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_READ_CONTACTS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                loadContacts();
            } else {
                statusText.setText("Izin ditolak. Aplikasi tidak bisa membaca kontak.");
                Toast.makeText(this, "Izinkan akses Kontak untuk melanjutkan.", Toast.LENGTH_LONG).show();
            }
        } else if (requestCode == REQUEST_CONTACT_PERMISSIONS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                showAddContactsDialog();
            } else {
                Toast.makeText(this, "Izin menulis kontak ditolak.", Toast.LENGTH_LONG).show();
            }
        }
    }

    private static class ContactItem {
        final long id;
        final String name;
        final List<NumberItem> numbers = new ArrayList<>();
        ContactItem(long id, String name) {
            this.id = id;
            this.name = name;
        }
    }

    private static class NumberItem {
        final long contactId;
        final String number;
        boolean whatsappLinked = false;
        boolean telegramLinked = false;
        NumberItem(long contactId, String number) {
            this.contactId = contactId;
            this.number = number;
        }
    }
}
