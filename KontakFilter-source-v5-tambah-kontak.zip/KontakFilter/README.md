# KontakFilter

Aplikasi Android Java untuk membaca nomor kontak dan mencoba mendeteksi baris data integrasi aplikasi yang diekspos oleh Android Contacts Provider.

## Penting tentang deteksi WhatsApp/Telegram
Aplikasi memeriksa MIME type pada `ContactsContract.Data` yang mengandung teks `whatsapp` atau `telegram`. Ini hanya pemeriksaan best-effort. Android dan aplikasi pihak ketiga tidak menjamin bahwa indikator yang muncul pada layar detail kontak akan tersedia melalui query ini. Jika tidak ditemukan, itu **bukan bukti** bahwa nomor tidak terdaftar. Kode ini tidak login ke akun WhatsApp/Telegram dan tidak mengirim kontak ke server.

## Privasi
- Meminta izin `READ_CONTACTS` dan `WRITE_CONTACTS` saat fitur terkait digunakan.
- Pemrosesan dilakukan lokal di perangkat.
- Tidak mengirim kontak ke server.
- Fitur **Tambah Kontak Berurutan** menyimpan kontak langsung ke buku kontak Android, tanpa bot token. Pengguna memasukkan nomor awal, jumlah (maksimal 1.000), dan nama dasar; nomor yang sudah ada dilewati. Nomor yang dihasilkan belum tentu aktif atau terdaftar di layanan pesan.

## Build APK dari HP dengan GitHub Actions
1. Ekstrak ZIP ini.
2. Buat repository baru di GitHub dari browser HP.
3. Upload isi proyek dengan struktur folder tetap, termasuk `.github/workflows/build-apk.yml`.
4. Buka tab **Actions**.
5. Pilih **Build KontakFilter APK** lalu tekan **Run workflow**.
6. Setelah selesai, unduh artifact `KontakFilter-debug-apk`.
7. Ekstrak artifact dan instal `app-debug.apk`.

## Catatan teknis
- Java 17, Android Gradle Plugin 8.7.3, compile SDK 35, min SDK 23.
- Build ini belum diuji pada perangkat pengguna; verifikasi hasil workflow sebelum instalasi.
- APK debug untuk pengujian, bukan rilis Play Store.
